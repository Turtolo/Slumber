using Gum.Converters;
using Gum.DataTypes;
using Gum.Managers;
using Gum.Wireframe;

using RenderingLibrary.Graphics;

using System.Linq;

namespace Slumber.Components.Elements
{
    partial class PercentBarIcon
    {
        partial void CustomInitialize()
        {
        
        }
    }
}
